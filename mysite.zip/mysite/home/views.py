from django.contrib.auth import authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect, get_object_or_404

# Create your views here.
from home.forms import TodoForm
from home.models import Todo


def home1(request):
    return render(request,'home1.html')


def todoadd(request):
    todoform= TodoForm(request.POST or None)
    if todoform.is_valid():
        todoform.save()
        return redirect('alltodo')
    return render (request,'todoadd.html',{'form': todoform})

def alltodo(request):
    all = Todo.objects.all()
    return render(request,'alltodo.html',{'todos': all})

def todoedit(request, pk):
    home = get_object_or_404(Todo,pk=pk)
    todoform =TodoForm(request.POST or None, instance=home)
    if todoform.is_valid():
        todoform.save()
        return redirect('alltodo')
    return render (request,'todoadd.html',{'form': todoform})

def tododelete(request, pk):
    home = get_object_or_404(Todo,pk=pk)
    if request.method=='POST':
        home.delete()
        return redirect('alltodo')
    return render(request,'tododelete.html',{'todo':home})

'''def user(request):
    var1 = request.POST['uname']
    var2 = request.POST['psw']
    print(var1)
    print(var2)
    return render(request,"home1.html",{'username':var1})'''