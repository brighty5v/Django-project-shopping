from django import forms

from home.models import Todo

class TodoForm(forms.ModelForm):
    class Meta:
        model=Todo
        fields={'title','description'}