from django.conf.urls import url
from django.contrib.auth import views
from django.urls import path

from home.views import todoadd, alltodo, todoedit, tododelete

urlpatterns = [
    path('todoadd', todoadd, name='todoadd'),
    path('alltodo', alltodo, name='alltodo'),
    path('<pk>todoedit', todoedit, name='todoedit'),
    path('<pk>tododelete', tododelete, name='tododelete'),

    ]
